/* @ds-bundle: {"format":4,"namespace":"MahoDesignSystem_2eb4f3","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"b9f214de0f7d","components/core/Button.jsx":"f7644546489a","components/core/Card.jsx":"13f070b62d6c","components/core/Icon.jsx":"21824fec28f0","components/core/IconButton.jsx":"b5af3440848f","components/core/Tag.jsx":"65d134f64361","components/feedback/Dialog.jsx":"7875694660b4","components/feedback/Toast.jsx":"c304ad5fe6a8","components/feedback/Tooltip.jsx":"ba8cf5f51b00","components/forms/Checkbox.jsx":"b6ea6d5a967c","components/forms/Field.jsx":"8e652c996f59","components/forms/Input.jsx":"7809bc804224","components/forms/Radio.jsx":"b99506a15864","components/forms/Select.jsx":"b94851fe6eaa","components/forms/Switch.jsx":"6def2287ba7a","components/navigation/Tabs.jsx":"b61fc1e6087e","ui_kits/app/AppShell.jsx":"7b04f1cb2717","ui_kits/app/Overview.jsx":"6ed22eab9aa9","ui_kits/app/SettingsView.jsx":"338ed97b5b8d","ui_kits/app/SignIn.jsx":"6185804e6f32","ui_kits/app/Signals.jsx":"82977065d47e","ui_kits/marketing/FeatureGrid.jsx":"75e004081dd0","ui_kits/marketing/Hero.jsx":"7f6cfffccae0","ui_kits/marketing/Pricing.jsx":"3b7d9a360556","ui_kits/marketing/SiteFooter.jsx":"c786f5a362c4","ui_kits/marketing/SiteNav.jsx":"9bac29ad4a2d","ui_kits/mobile/MobileHome.jsx":"2363ee56be67","ui_kits/mobile/MobileSettings.jsx":"ec61ba71413b","ui_kits/mobile/Phone.jsx":"fd7c2b42779b","ui_kits/mobile/SignalDetail.jsx":"14b8f5323f13"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MahoDesignSystem_2eb4f3 = window.MahoDesignSystem_2eb4f3 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Compact status marker. Mono, uppercase, outline-only. */
function Badge({
  tone = 'neutral',
  dot,
  children,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: ['ginei-badge', `ginei-badge--${tone}`, className].filter(Boolean).join(' ')
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    className: "ginei-badge__dot"
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Bounded surface: hairline border, generous padding, no heavy shadow. */
function Card({
  variant = 'default',
  eyebrow,
  title,
  actions,
  interactive,
  children,
  className = '',
  ...rest
}) {
  const cls = ['ginei-card', variant !== 'default' && `ginei-card--${variant}`, interactive && 'ginei-card--interactive', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), eyebrow && /*#__PURE__*/React.createElement("div", {
    className: "ginei-card__eyebrow"
  }, eyebrow), (title || actions) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 'var(--space-5)',
      marginBottom: children ? 'var(--space-5)' : 0
    }
  }, title && /*#__PURE__*/React.createElement("h4", {
    className: "ginei-card__title"
  }, title), actions), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CDN = 'https://unpkg.com/lucide-static@0.427.0/icons/';
/** Monochrome glyph from the Lucide static set, masked so it inherits currentColor. */
function Icon({
  name,
  size = 16,
  label,
  className = '',
  style,
  ...rest
}) {
  const url = `url("${CDN}${name}.svg")`;
  return /*#__PURE__*/React.createElement("span", _extends({
    className: ['ginei-icon', className].filter(Boolean).join(' '),
    role: label ? 'img' : 'presentation',
    "aria-label": label,
    "aria-hidden": label ? undefined : true,
    style: {
      width: size,
      height: size,
      WebkitMaskImage: url,
      maskImage: url,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Primary action control. One primary per view; seal variant is reserved for irreversible moments. */
function Button({
  variant = 'primary',
  size = 'md',
  icon,
  iconAfter,
  block,
  as = 'button',
  children,
  className = '',
  ...rest
}) {
  const Tag = as;
  const cls = ['ginei-btn', `ginei-btn--${variant}`, size !== 'md' && `ginei-btn--${size}`, block && 'ginei-btn--block', className].filter(Boolean).join(' ');
  const glyph = size === 'lg' ? 16 : 14;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls
  }, rest), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: glyph
  }), children, iconAfter && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconAfter,
    size: glyph
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Square, label-less control for toolbars and card corners. */
function IconButton({
  icon,
  label,
  size = 'md',
  variant = 'ghost',
  className = '',
  ...rest
}) {
  const cls = ['ginei-iconbtn', size !== 'md' && `ginei-iconbtn--${size}`, variant === 'outline' && 'ginei-iconbtn--outline', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    "aria-label": label,
    title: label
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 14 : size === 'lg' ? 18 : 16
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Pill for user-supplied metadata: filters, topics, recipients. */
function Tag({
  selected,
  onRemove,
  children,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: ['ginei-tag', selected && 'ginei-tag--selected', className].filter(Boolean).join(' ')
  }, rest), children, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Remove",
    onClick: onRemove
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 11
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
/** Modal decision point. Renders nothing when closed. */
function Dialog({
  open,
  title,
  onClose,
  footer,
  children,
  width,
  className = ''
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "ginei-dialog__scrim",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: ['ginei-dialog', className].filter(Boolean).join(' '),
    style: width ? {
      maxWidth: width
    } : undefined,
    role: "dialog",
    "aria-modal": "true",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "ginei-dialog__head"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "ginei-dialog__title"
  }, title), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    size: "sm",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    className: "ginei-dialog__body"
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    className: "ginei-dialog__foot"
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const GLYPH = {
  info: 'info',
  success: 'check',
  warning: 'triangle-alert',
  danger: 'circle-alert'
};
/** Transient confirmation, bottom-right, one at a time. */
function Toast({
  tone = 'info',
  title,
  description,
  onDismiss,
  className = ''
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: ['ginei-toast', tone !== 'info' && `ginei-toast--${tone}`, className].filter(Boolean).join(' '),
    role: "status"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: GLYPH[tone],
    size: 15,
    style: {
      marginTop: 2,
      color: `var(--status-${tone === 'info' ? 'info' : tone})`
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ginei-toast__title"
  }, title), description && /*#__PURE__*/React.createElement("div", {
    className: "ginei-toast__desc"
  }, description)), onDismiss && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Dismiss",
    size: "sm",
    onClick: onDismiss
  }));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
/** Hover/focus label for icon-only controls. Never holds essential copy. */
function Tooltip({
  content,
  placement = 'top',
  children,
  className = ''
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: ['ginei-tooltip', className].filter(Boolean).join(' ')
  }, children, /*#__PURE__*/React.createElement("span", {
    className: `ginei-tooltip__bubble ginei-tooltip__bubble--${placement}`
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const MARK = 'url("https://unpkg.com/lucide-static@0.427.0/icons/check.svg")';
/** Square multi-select control. */
function Checkbox({
  label,
  disabled,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ['ginei-check', disabled && 'ginei-check--disabled', className].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "ginei-check__box"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ginei-check__mark",
    style: {
      '--mark': MARK
    }
  })), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Label + hint + error wrapper shared by every form control. */
function Field({
  label,
  hint,
  error,
  htmlFor,
  children,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ['ginei-field', className].filter(Boolean).join(' ')
  }, rest), label && /*#__PURE__*/React.createElement("label", {
    className: "ginei-field__label",
    htmlFor: htmlFor
  }, label), children, error ? /*#__PURE__*/React.createElement("span", {
    className: "ginei-field__error"
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "ginei-field__hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Single-line or multiline text entry on an inset surface. */
function Input({
  multiline,
  invalid,
  rows = 4,
  className = '',
  ...rest
}) {
  const cls = ['ginei-input', multiline && 'ginei-input--textarea', invalid && 'ginei-input--invalid', className].filter(Boolean).join(' ');
  return multiline ? /*#__PURE__*/React.createElement("textarea", _extends({
    className: cls,
    rows: rows,
    "aria-invalid": invalid || undefined
  }, rest)) : /*#__PURE__*/React.createElement("input", _extends({
    className: cls,
    "aria-invalid": invalid || undefined
  }, rest));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Round single-select control. Share a name across a group. */
function Radio({
  label,
  disabled,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ['ginei-check', 'ginei-check--radio', disabled && 'ginei-check--disabled', className].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "ginei-check__box"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ginei-check__mark"
  })), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
/** Native select with Ginei chrome. Options are {value,label} or plain strings. */
function Select({
  options = [],
  placeholder,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: ['ginei-select', className].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement("select", rest, placeholder && /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), options.map(o => {
    const v = typeof o === 'string' ? o : o.value;
    const l = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })), /*#__PURE__*/React.createElement("span", {
    className: "ginei-select__caret"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 12
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Immediate on/off setting. Never used to submit a form. */
function Switch({
  label,
  disabled,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ['ginei-switch', disabled && 'ginei-switch--disabled', className].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "ginei-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ginei-switch__thumb"
  })), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Controlled view switcher. Underline for page level, pill for panel level. */
function Tabs({
  items = [],
  value,
  onChange,
  variant = 'underline',
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    className: ['ginei-tabs', variant === 'pill' && 'ginei-tabs--pill', className].filter(Boolean).join(' ')
  }, rest), items.map(it => {
    const v = typeof it === 'string' ? it : it.value;
    const l = typeof it === 'string' ? it : it.label;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      role: "tab",
      type: "button",
      className: "ginei-tab",
      "aria-selected": v === value,
      onClick: () => onChange && onChange(v)
    }, l);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/AppShell.jsx
try { (() => {
const {
  Icon,
  IconButton,
  Tooltip,
  Badge
} = window.MahoDesignSystem_2eb4f3;
const NAV = [['Overview', 'layout-dashboard'], ['Signals', 'activity'], ['Traces', 'git-branch'], ['Sources', 'plug'], ['Settings', 'settings']];
function AppShell({
  view,
  onView,
  onSignOut,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100vh'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 240,
      flex: 'none',
      borderRight: '1px solid var(--border-hairline)',
      background: 'var(--bg-base)',
      display: 'flex',
      flexDirection: 'column',
      padding: 'var(--space-6) var(--space-5)',
      gap: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 20,
      letterSpacing: '.06em',
      color: 'var(--text-strong)'
    }
  }, "Ginei"), /*#__PURE__*/React.createElement(Badge, null, "beta")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-1)'
    }
  }, NAV.map(([n, icon]) => {
    const active = n === view;
    return /*#__PURE__*/React.createElement("button", {
      key: n,
      onClick: () => onView(n),
      style: {
        all: 'unset',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-4)',
        padding: 'var(--space-3) var(--space-4)',
        borderRadius: 'var(--radius-sm)',
        fontSize: 'var(--text-body-md)',
        color: active ? 'var(--text-strong)' : 'var(--text-muted)',
        background: active ? 'var(--accent-quiet)' : 'transparent',
        boxShadow: active ? 'var(--glow-edge)' : 'none'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: icon,
      size: 16
    }), n);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-hairline)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 28,
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--border-strong)',
      display: 'grid',
      placeItems: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-muted)'
    }
  }, "R"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-body)'
    }
  }, "Rin Aoki"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-faint)'
    }
  }, "ginei-core")), /*#__PURE__*/React.createElement(Tooltip, {
    content: "Sign out",
    placement: "top"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "log-out",
    label: "Sign out",
    size: "sm",
    onClick: onSignOut
  }))))), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 30,
      height: 60,
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-5)',
      padding: '0 var(--space-7)',
      borderBottom: '1px solid var(--border-hairline)',
      background: 'color-mix(in srgb, var(--bg-canvas) 80%, transparent)',
      backdropFilter: 'blur(20px)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--text-heading)'
    }
  }, view), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: 260
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: "ginei-input",
    placeholder: "Search signals",
    style: {
      paddingLeft: 34
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 12,
      top: '50%',
      transform: 'translateY(-50%)',
      color: 'var(--text-faint)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 14
  }))), /*#__PURE__*/React.createElement(IconButton, {
    icon: "bell",
    label: "Notifications"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "moon-star",
    label: "Theme",
    onClick: () => {
      const l = document.body.dataset.theme === 'light';
      document.body.dataset.theme = l ? '' : 'light';
      document.documentElement.dataset.theme = l ? '' : 'light';
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: 'var(--space-7)'
    }
  }, children)));
}
Object.assign(window, {
  AppShell
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Overview.jsx
try { (() => {
const {
  Card,
  Badge,
  Button,
  Tabs,
  Icon,
  Tag,
  Dialog
} = window.MahoDesignSystem_2eb4f3;
const ROWS = [['ingest-api', 'Healthy', '142 ms', '12:04', 'success'], ['trace-collector', 'Healthy', '88 ms', '12:04', 'success'], ['baseline-worker', 'Degraded', '1.9 s', '12:01', 'warning'], ['export-eu', 'Healthy', '203 ms', '12:03', 'success'], ['export-jp', 'Failed', '—', '11:58', 'danger']];
function Overview({
  onNotify
}) {
  const [range, setRange] = React.useState('day');
  const [confirm, setConfirm] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)',
      maxWidth: 1160
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    variant: "pill",
    value: range,
    onChange: setRange,
    items: [{
      value: 'day',
      label: 'Day'
    }, {
      value: 'week',
      label: 'Week'
    }, {
      value: 'month',
      label: 'Month'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "download",
    size: "sm",
    onClick: () => onNotify({
      tone: 'success',
      title: 'Snapshot saved',
      description: 'ginei-core · 12:04'
    })
  }, "Save snapshot"), /*#__PURE__*/React.createElement(Button, {
    variant: "seal",
    size: "sm",
    onClick: () => setConfirm(true)
  }, "Pause ingest")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 'var(--space-5)'
    }
  }, [['Median latency', '142 ms', 'accent'], ['Uptime', '99.98%', 'success'], ['Sources', '12', 'neutral'], ['Open incidents', '1', 'warning']].map(([k, v, tone]) => /*#__PURE__*/React.createElement(Card, {
    key: k,
    eyebrow: k
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 28,
      color: 'var(--text-strong)',
      lineHeight: 1
    }
  }, v), /*#__PURE__*/React.createElement(Badge, {
    tone: tone,
    dot: tone !== 'neutral'
  }, tone === 'warning' ? 'attention' : 'steady'))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.6fr 1fr',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Latency",
    actions: /*#__PURE__*/React.createElement(Tag, {
      selected: true
    }, "p50")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 180,
      display: 'flex',
      alignItems: 'flex-end',
      gap: 4
    }
  }, [22, 30, 26, 38, 34, 44, 40, 52, 47, 58, 54, 62, 57, 68, 63, 74, 69, 80, 76, 86].map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: h + '%',
      background: 'linear-gradient(180deg,#8CBFE4aa,#8CBFE414)',
      borderTop: '1px solid var(--accent-solid)'
    }
  })))), /*#__PURE__*/React.createElement(Card, {
    variant: "glow",
    title: "Baseline delta"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, [['ingest-api', '+2%'], ['trace-collector', '−1%'], ['baseline-worker', '+38%'], ['export-eu', '0%']].map(([n, d]) => /*#__PURE__*/React.createElement("div", {
    key: n,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      fontSize: 'var(--text-body-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, n), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      color: d.startsWith('+3') ? 'var(--status-warning)' : 'var(--text-body)'
    }
  }, d)))))), /*#__PURE__*/React.createElement(Card, {
    variant: "quiet",
    style: {
      padding: 0,
      border: '1px solid var(--border-hairline)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 'var(--text-body-sm)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ['Service', 'Status', 'p50', 'Last seen', ''].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      textAlign: 'left',
      padding: 'var(--space-4) var(--space-5)',
      borderBottom: '1px solid var(--border-hairline)',
      font: 'var(--type-label)',
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)'
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, ROWS.map(([n, s, p, t, tone]) => /*#__PURE__*/React.createElement("tr", {
    key: n
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: 'var(--space-4) var(--space-5)',
      borderBottom: '1px solid var(--border-hairline)',
      color: 'var(--text-body)'
    }
  }, n), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: 'var(--space-4) var(--space-5)',
      borderBottom: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: tone,
    dot: true
  }, s)), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: 'var(--space-4) var(--space-5)',
      borderBottom: '1px solid var(--border-hairline)',
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-muted)'
    }
  }, p), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: 'var(--space-4) var(--space-5)',
      borderBottom: '1px solid var(--border-hairline)',
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-faint)'
    }
  }, t), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: 'var(--space-4) var(--space-5)',
      borderBottom: '1px solid var(--border-hairline)',
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 14,
    style: {
      color: 'var(--text-faint)'
    }
  }))))))), /*#__PURE__*/React.createElement(Dialog, {
    open: confirm,
    title: "Pause ingest for ginei-core?",
    onClose: () => setConfirm(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setConfirm(false)
    }, "Keep running"), /*#__PURE__*/React.createElement(Button, {
      variant: "seal",
      onClick: () => {
        setConfirm(false);
        onNotify({
          tone: 'warning',
          title: 'Ingest paused',
          description: 'Resume any time from Sources.'
        });
      }
    }, "Pause"))
  }, "Nothing is collected while ingest is paused. Existing history is untouched."));
}
Object.assign(window, {
  Overview
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Overview.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/SettingsView.jsx
try { (() => {
const {
  Card,
  Field,
  Input,
  Select,
  Switch,
  Radio,
  Checkbox,
  Button,
  Tabs,
  Badge
} = window.MahoDesignSystem_2eb4f3;
function SettingsView({
  onNotify
}) {
  const [tab, setTab] = React.useState('Workspace');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 820,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    items: ['Workspace', 'Notifications', 'Retention'],
    value: tab,
    onChange: setTab
  }), tab === 'Workspace' && /*#__PURE__*/React.createElement(Card, {
    title: "Workspace",
    actions: /*#__PURE__*/React.createElement(Badge, {
      tone: "accent"
    }, "ginei-core"),
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Name",
    hint: "Lowercase, no spaces"
  }, /*#__PURE__*/React.createElement(Input, {
    defaultValue: "ginei-core"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Region",
    hint: "Data never leaves this region"
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['Tokyo', 'Osaka', 'Frankfurt'],
    defaultValue: "Tokyo"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Owner"
  }, /*#__PURE__*/React.createElement(Input, {
    defaultValue: "rin@ginei.co"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Note"
  }, /*#__PURE__*/React.createElement(Input, {
    multiline: true,
    rows: 3,
    placeholder: "Anything the team should know"
  }))), tab === 'Notifications' && /*#__PURE__*/React.createElement(Card, {
    title: "Notifications",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    label: "Calm alerting \u2014 one notification per incident",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Email digest on Mondays",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Notify on baseline drift under 5%"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-hairline)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "ginei-label"
  }, "Deliver to"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement(Radio, {
    name: "d",
    label: "Email",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "d",
    label: "Webhook"
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "d",
    label: "Both"
  }))), tab === 'Retention' && /*#__PURE__*/React.createElement(Card, {
    title: "Retention",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "History window"
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['7 days', '30 days', '90 days', '1 year'],
    defaultValue: "90 days"
  })), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Keep traces for failed requests beyond the window",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Allow export to object storage"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost"
  }, "Discard"), /*#__PURE__*/React.createElement(Button, {
    onClick: () => onNotify({
      tone: 'success',
      title: 'Settings saved'
    })
  }, "Save changes")));
}
Object.assign(window, {
  SettingsView
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/SettingsView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/SignIn.jsx
try { (() => {
const {
  Card,
  Field,
  Input,
  Button,
  Checkbox
} = window.MahoDesignSystem_2eb4f3;
function SignIn({
  onSignIn
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'grid',
      placeItems: 'center',
      padding: 'var(--space-6)',
      background: 'radial-gradient(50% 50% at 50% 30%, #8CBFE40f, transparent 70%), var(--bg-canvas)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 380,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 30,
      letterSpacing: '.06em',
      color: 'var(--text-strong)'
    }
  }, "Ginei"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, "Sign in to your workspace.")), /*#__PURE__*/React.createElement(Card, {
    variant: "raised",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Email",
    htmlFor: "e"
  }, /*#__PURE__*/React.createElement(Input, {
    id: "e",
    defaultValue: "rin@ginei.co"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Password",
    htmlFor: "p"
  }, /*#__PURE__*/React.createElement(Input, {
    id: "p",
    type: "password",
    defaultValue: "\xB7\xB7\xB7\xB7\xB7\xB7\xB7\xB7"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Keep me signed in",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontSize: 'var(--text-body-sm)'
    }
  }, "Forgot?")), /*#__PURE__*/React.createElement(Button, {
    block: true,
    onClick: onSignIn,
    iconAfter: "arrow-right"
  }, "Sign in")), /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: 'center',
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-faint)'
    }
  }, "No account? ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: onSignIn
  }, "Request access"))));
}
Object.assign(window, {
  SignIn
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/SignIn.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Signals.jsx
try { (() => {
const {
  Card,
  Tag,
  Badge,
  Select,
  Input,
  Button,
  Icon,
  Tooltip,
  IconButton
} = window.MahoDesignSystem_2eb4f3;
const SIGNALS = [['Latency above baseline', 'baseline-worker', 'warning', '12:01', 'p50 rose 38% against a 7-day baseline.'], ['Export failing', 'export-jp', 'danger', '11:58', 'Three consecutive failures. Last error: connection reset.'], ['New source connected', 'stripe-events', 'success', '11:40', 'Twelve sources are now reporting.'], ['Retention changed', 'ginei-core', 'neutral', '09:12', 'History window set to 90 days by Rin Aoki.']];
function Signals({
  onNotify
}) {
  const [filter, setFilter] = React.useState('all');
  const list = SIGNALS.filter(s => filter === 'all' || s[2] === filter);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '260px 1fr',
      gap: 'var(--space-6)',
      maxWidth: 1160
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Filter signals"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ginei-label",
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, "Severity"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'var(--space-2)'
    }
  }, ['all', 'danger', 'warning', 'success'].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    selected: filter === t,
    onClick: () => setFilter(t),
    style: {
      cursor: 'pointer'
    }
  }, t)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ginei-label",
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, "Source"), /*#__PURE__*/React.createElement(Select, {
    placeholder: "All sources",
    options: ['ingest-api', 'trace-collector', 'export-jp']
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, list.map(([title, src, tone, time, body]) => /*#__PURE__*/React.createElement(Card, {
    key: title,
    interactive: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: tone,
    dot: tone !== 'neutral'
  }, tone), /*#__PURE__*/React.createElement("h4", {
    className: "ginei-card__title"
  }, title)), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'var(--space-3)',
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, body), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-4)',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-faint)'
    }
  }, src, " \xB7 ", time)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement(Tooltip, {
    content: "Copy id"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "copy",
    label: "Copy id",
    size: "sm",
    onClick: () => onNotify({
      tone: 'info',
      title: 'Signal id copied'
    })
  })), /*#__PURE__*/React.createElement(Tooltip, {
    content: "Mute"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "bell-off",
    label: "Mute",
    size: "sm",
    onClick: () => onNotify({
      tone: 'info',
      title: 'Signal muted',
      description: 'For 24 hours.'
    })
  })))))), list.length === 0 && /*#__PURE__*/React.createElement(Card, {
    variant: "quiet",
    style: {
      textAlign: 'center',
      padding: 'var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "inbox",
    size: 20,
    style: {
      color: 'var(--text-faint)'
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'var(--space-4)',
      color: 'var(--text-muted)'
    }
  }, "Nothing at this severity. Widen the filter to see more."))));
}
Object.assign(window, {
  Signals
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Signals.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/FeatureGrid.jsx
try { (() => {
const {
  Card,
  Icon
} = window.MahoDesignSystem_2eb4f3;
const FEATURES = [['layers', 'One surface', 'Every source, every signal, in a single view. No tab archaeology.'], ['activity', 'Only what changed', 'Ginei holds a baseline and surfaces the delta. Quiet by default.'], ['shield', 'Yours alone', 'Data stays in your region. Retention is set by you, not by us.'], ['git-branch', 'Traced end to end', 'Follow a request across services without leaving the page.'], ['bell', 'Calm alerting', 'One notification per incident, with the context already attached.'], ['plug', 'Twelve integrations', 'Connect a source in a minute. No agents to install.']];
function FeatureGrid() {
  return /*#__PURE__*/React.createElement("section", {
    className: "mk-wrap",
    style: {
      padding: 'var(--space-10) var(--gutter-inline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 'var(--space-8)',
      marginBottom: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ginei-label"
  }, "What it does"), /*#__PURE__*/React.createElement("h2", {
    style: {
      marginTop: 'var(--space-4)',
      maxWidth: '22ch'
    }
  }, "Precision without noise.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-muted)',
      maxWidth: '42ch'
    }
  }, "Six things Ginei does well, and nothing it does adequately.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-5)'
    }
  }, FEATURES.map(([icon, title, body]) => /*#__PURE__*/React.createElement(Card, {
    key: title,
    interactive: true
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 18,
    style: {
      color: 'var(--text-accent)'
    }
  }), /*#__PURE__*/React.createElement("h4", {
    className: "ginei-card__title",
    style: {
      marginTop: 'var(--space-5)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'var(--space-3)',
      fontSize: 'var(--text-body-sm)',
      lineHeight: 'var(--leading-normal)',
      color: 'var(--text-muted)'
    }
  }, body)))));
}
Object.assign(window, {
  FeatureGrid
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/FeatureGrid.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/Hero.jsx
try { (() => {
const {
  Button,
  Badge
} = window.MahoDesignSystem_2eb4f3;
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderBottom: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'radial-gradient(60% 70% at 50% 0%, #8CBFE414, transparent 70%)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "mk-wrap",
    style: {
      position: 'relative',
      padding: 'var(--space-10) var(--gutter-inline) var(--space-10)',
      textAlign: 'center',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "accent"
  }, "Now in open beta"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-display-1)',
      lineHeight: 'var(--leading-tight)',
      maxWidth: '14ch'
    }
  }, "Stillness scales."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-lg)',
      lineHeight: 'var(--leading-normal)',
      color: 'var(--text-muted)',
      maxWidth: '52ch'
    }
  }, "Ginei keeps every signal in one place and shows you only what changed. Nothing is hidden; nothing shouts."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      marginTop: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    iconAfter: "arrow-right"
  }, "Begin"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "secondary",
    icon: "play"
  }, "Watch the tour")), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      marginTop: 'var(--space-8)',
      height: 300,
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-hairline)',
      background: 'var(--surface-card)',
      boxShadow: 'var(--glow-accent), var(--shadow-lg)',
      display: 'flex',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 200,
      borderRight: '1px solid var(--border-hairline)',
      padding: 'var(--space-5)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, ['Overview', 'Signals', 'Traces', 'Sources', 'Settings'].map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s,
    style: {
      fontSize: 'var(--text-body-sm)',
      color: i === 0 ? 'var(--text-strong)' : 'var(--text-faint)'
    }
  }, s))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: 'var(--space-6)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-5)'
    }
  }, [['Latency', '142 ms'], ['Uptime', '99.98%'], ['Sources', '12']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      flex: 1,
      border: '1px solid var(--border-hairline)',
      borderRadius: 'var(--radius-md)',
      padding: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ginei-card__eyebrow"
  }, k), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 22,
      color: 'var(--text-strong)'
    }
  }, v)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      border: '1px solid var(--border-hairline)',
      borderRadius: 'var(--radius-md)',
      display: 'flex',
      alignItems: 'flex-end',
      gap: 6,
      padding: 'var(--space-4)'
    }
  }, [18, 32, 26, 44, 38, 58, 49, 66, 54, 72, 61, 80, 70, 88].map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: h + '%',
      background: 'linear-gradient(180deg,#8CBFE4aa,#8CBFE41a)',
      borderTop: '1px solid var(--accent-solid)'
    }
  })))))));
}
Object.assign(window, {
  Hero
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/Pricing.jsx
try { (() => {
const {
  Card,
  Button,
  Badge,
  Icon,
  Tabs
} = window.MahoDesignSystem_2eb4f3;
const PLANS = [['Solo', '$0', ['One workspace', 'Three sources', '7-day history'], 'secondary'], ['Team', '$24', ['Unlimited workspaces', 'Twelve sources', '90-day history', 'Calm alerting'], 'primary'], ['Estate', 'Talk to us', ['Your region, your retention', 'SSO and audit log', 'Dedicated review'], 'secondary']];
function Pricing() {
  const [cycle, setCycle] = React.useState('month');
  return /*#__PURE__*/React.createElement("section", {
    style: {
      borderTop: '1px solid var(--border-hairline)',
      background: 'var(--bg-canvas)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-wrap",
    style: {
      padding: 'var(--space-10) var(--gutter-inline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 'var(--space-5)',
      marginBottom: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("h2", null, "Pricing"), /*#__PURE__*/React.createElement(Tabs, {
    variant: "pill",
    value: cycle,
    onChange: setCycle,
    items: [{
      value: 'month',
      label: 'Monthly'
    }, {
      value: 'year',
      label: 'Annual'
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-5)',
      alignItems: 'start'
    }
  }, PLANS.map(([name, price, lines, variant]) => {
    const featured = variant === 'primary';
    const amount = price.startsWith('$') && cycle === 'year' && price !== '$0' ? '$' + parseInt(price.slice(1), 10) * 10 : price;
    return /*#__PURE__*/React.createElement(Card, {
      key: name,
      variant: featured ? 'glow' : 'default',
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 'var(--space-5)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 'var(--text-heading)',
        color: 'var(--text-strong)'
      }
    }, name), featured && /*#__PURE__*/React.createElement(Badge, {
      tone: "accent"
    }, "Most chosen")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 32,
        color: 'var(--text-strong)'
      }
    }, amount, price.startsWith('$') && price !== '$0' && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: 'var(--text-faint)'
      }
    }, " / ", cycle === 'month' ? 'mo' : 'yr')), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 'var(--space-3)'
      }
    }, lines.map(l => /*#__PURE__*/React.createElement("div", {
      key: l,
      style: {
        display: 'flex',
        gap: 'var(--space-3)',
        alignItems: 'center',
        fontSize: 'var(--text-body-sm)',
        color: 'var(--text-muted)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "check",
      size: 13,
      style: {
        color: 'var(--status-success)'
      }
    }), l))), /*#__PURE__*/React.createElement(Button, {
      variant: variant,
      block: true
    }, price === 'Talk to us' ? 'Contact sales' : 'Choose ' + name));
  }))));
}
Object.assign(window, {
  Pricing
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/Pricing.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/SiteFooter.jsx
try { (() => {
const {
  Input,
  Button
} = window.MahoDesignSystem_2eb4f3;
const COLS = [['Product', ['Overview', 'Signals', 'Traces', 'Changelog']], ['Company', ['About', 'Careers', 'Contact']], ['Resources', ['Docs', 'Status', 'Security']]];
function SiteFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-wrap",
    style: {
      padding: 'var(--space-9) var(--gutter-inline)',
      display: 'grid',
      gridTemplateColumns: '1.6fr repeat(3,1fr)',
      gap: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 22,
      letterSpacing: '.06em',
      color: 'var(--text-strong)'
    }
  }, "Ginei"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      maxWidth: '34ch'
    }
  }, "One quiet place for everything you watch."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      maxWidth: 320
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "you@company.com"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary"
  }, "Notify me"))), COLS.map(([title, links]) => /*#__PURE__*/React.createElement("div", {
    key: title,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ginei-label"
  }, title), links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      borderBottom: 'none'
    }
  }, l))))), /*#__PURE__*/React.createElement("div", {
    className: "mk-wrap",
    style: {
      padding: 'var(--space-5) var(--gutter-inline)',
      borderTop: '1px solid var(--border-hairline)',
      display: 'flex',
      justifyContent: 'space-between',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-faint)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Ginei"), /*#__PURE__*/React.createElement("span", null, "Tokyo \xB7 Berlin")));
}
Object.assign(window, {
  SiteFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/SiteFooter.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/SiteNav.jsx
try { (() => {
const {
  Button,
  IconButton,
  Icon
} = window.MahoDesignSystem_2eb4f3;
const NAV = ['Product', 'Signals', 'Pricing', 'Docs'];
function SiteNav({
  theme,
  onToggleTheme
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 40,
      background: 'color-mix(in srgb, var(--bg-base) 80%, transparent)',
      backdropFilter: 'blur(20px)',
      borderBottom: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-wrap",
    style: {
      height: 64,
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 22,
      letterSpacing: '.06em',
      color: 'var(--text-strong)'
    }
  }, "Ginei"), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      flex: 1
    }
  }, NAV.map((n, i) => /*#__PURE__*/React.createElement("a", {
    key: n,
    href: "#",
    style: {
      fontSize: 'var(--text-body-sm)',
      color: i === 0 ? 'var(--text-strong)' : 'var(--text-muted)',
      borderBottom: 'none'
    }
  }, n))), /*#__PURE__*/React.createElement(IconButton, {
    icon: theme === 'dark' ? 'sun' : 'moon-star',
    label: "Switch theme",
    onClick: onToggleTheme
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "Sign in"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    iconAfter: "arrow-right"
  }, "Begin")));
}
Object.assign(window, {
  SiteNav
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/SiteNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile/MobileHome.jsx
try { (() => {
const {
  Card,
  Badge,
  Icon,
  Tag,
  IconButton
} = window.MahoDesignSystem_2eb4f3;
const SIGNALS = [['Latency above baseline', 'baseline-worker', 'warning', '12:01'], ['Export failing', 'export-jp', 'danger', '11:58'], ['New source connected', 'stripe-events', 'success', '11:40'], ['Retention changed', 'ginei-core', 'neutral', '09:12']];
function MobileHome({
  onOpen,
  listOnly
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-6)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ginei-label"
  }, "ginei-core"), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: 6,
      fontSize: 'var(--text-title)'
    }
  }, listOnly ? 'Signals' : 'Good morning')), /*#__PURE__*/React.createElement(IconButton, {
    icon: "bell",
    label: "Notifications",
    variant: "outline"
  })), !listOnly && /*#__PURE__*/React.createElement(Card, {
    variant: "glow",
    style: {
      padding: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ginei-card__eyebrow"
  }, "Median latency"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 34,
      color: 'var(--text-strong)',
      lineHeight: 1
    }
  }, "142 ms"), /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    dot: true
  }, "steady")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-5)',
      height: 64,
      display: 'flex',
      alignItems: 'flex-end',
      gap: 3
    }
  }, [30, 38, 34, 46, 42, 54, 49, 60, 55, 66, 62, 72, 68, 78].map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: h + '%',
      background: 'linear-gradient(180deg,#8CBFE4aa,#8CBFE414)',
      borderTop: '1px solid var(--accent-solid)'
    }
  })))), !listOnly && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, [['Uptime', '99.98%'], ['Sources', '12'], ['Open', '1']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      flex: 1,
      border: '1px solid var(--border-hairline)',
      borderRadius: 'var(--radius-md)',
      padding: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ginei-label",
    style: {
      fontSize: 9
    }
  }, k), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4,
      fontFamily: 'var(--font-mono)',
      fontSize: 15,
      color: 'var(--text-strong)'
    }
  }, v)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ginei-label"
  }, "Recent signals"), /*#__PURE__*/React.createElement(Tag, {
    selected: true
  }, "today")), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border-hairline)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden'
    }
  }, SIGNALS.map(([title, src, tone, time], i) => /*#__PURE__*/React.createElement("button", {
    key: title,
    onClick: () => onOpen({
      title,
      src,
      tone,
      time
    }),
    style: {
      all: 'unset',
      cursor: 'pointer',
      display: 'flex',
      width: '100%',
      boxSizing: 'border-box',
      minHeight: 44,
      alignItems: 'center',
      gap: 'var(--space-4)',
      padding: 'var(--space-4) var(--space-5)',
      borderTop: i ? '1px solid var(--border-hairline)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: tone === 'neutral' ? 'var(--text-faint)' : `var(--status-${tone})`
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-body)'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      marginTop: 2,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-faint)'
    }
  }, src, " \xB7 ", time)), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 14,
    style: {
      color: 'var(--text-faint)'
    }
  }))))));
}
Object.assign(window, {
  MobileHome
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile/MobileHome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile/MobileSettings.jsx
try { (() => {
const {
  Card,
  Switch,
  Field,
  Select,
  Icon,
  Button
} = window.MahoDesignSystem_2eb4f3;
function MobileSettings() {
  const [night, setNight] = React.useState(true);
  React.useEffect(() => {
    document.body.dataset.theme = night ? '' : 'light';
    document.documentElement.dataset.theme = night ? '' : 'light';
  }, [night]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-6)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ginei-label"
  }, "Account"), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: 6,
      fontSize: 'var(--text-title)'
    }
  }, "Settings")), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 'var(--space-5)',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 999,
      border: '1px solid var(--border-strong)',
      display: 'grid',
      placeItems: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "R"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-strong)'
    }
  }, "Rin Aoki"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-faint)'
    }
  }, "rin@ginei.co")), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 14,
    style: {
      color: 'var(--text-faint)'
    }
  })), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 'var(--space-5)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    label: "Night mode",
    checked: night,
    onChange: e => setNight(e.target.checked)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-hairline)'
    }
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Calm alerting",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-hairline)'
    }
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Weekly digest",
    defaultChecked: true
  })), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "History window"
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['7 days', '30 days', '90 days'],
    defaultValue: "90 days"
  }))), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "log-out",
    block: true
  }, "Sign out"));
}
Object.assign(window, {
  MobileSettings
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile/MobileSettings.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile/Phone.jsx
try { (() => {
const {
  Icon
} = window.MahoDesignSystem_2eb4f3;
const TABS = [['Home', 'house'], ['Signals', 'activity'], ['Settings', 'settings']];
function Phone({
  tab,
  onTab,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 390,
      height: 844,
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-hairline)',
      background: 'var(--bg-base)',
      boxShadow: 'var(--shadow-lg)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 var(--space-6)',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "12:04"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "wifi",
    size: 12
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "battery-full",
    size: 14
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto'
    }
  }, children), /*#__PURE__*/React.createElement("nav", {
    style: {
      height: 64,
      flex: 'none',
      display: 'flex',
      borderTop: '1px solid var(--border-hairline)',
      background: 'color-mix(in srgb, var(--bg-base) 82%, transparent)',
      backdropFilter: 'blur(20px)'
    }
  }, TABS.map(([n, icon]) => {
    const active = n === tab;
    return /*#__PURE__*/React.createElement("button", {
      key: n,
      onClick: () => onTab(n),
      style: {
        all: 'unset',
        cursor: 'pointer',
        flex: 1,
        minHeight: 44,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 4,
        color: active ? 'var(--text-accent)' : 'var(--text-faint)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: icon,
      size: 18
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 9,
        letterSpacing: '.14em',
        textTransform: 'uppercase'
      }
    }, n));
  })));
}
Object.assign(window, {
  Phone
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile/Phone.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile/SignalDetail.jsx
try { (() => {
const {
  Card,
  Badge,
  Button,
  Icon,
  IconButton
} = window.MahoDesignSystem_2eb4f3;
function SignalDetail({
  signal,
  onBack
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 10,
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      padding: 'var(--space-4) var(--space-5)',
      borderBottom: '1px solid var(--border-hairline)',
      background: 'color-mix(in srgb, var(--bg-base) 82%, transparent)',
      backdropFilter: 'blur(20px)'
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "arrow-left",
    label: "Back",
    onClick: onBack
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-faint)'
    }
  }, signal.src)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-6)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: signal.tone,
    dot: signal.tone !== 'neutral'
  }, signal.tone), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--text-title)',
      lineHeight: 'var(--leading-snug)'
    }
  }, signal.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-muted)',
      lineHeight: 'var(--leading-normal)'
    }
  }, "p50 rose against a 7-day baseline. No change was deployed in the window.")), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ginei-card__eyebrow"
  }, "Against baseline"), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 110,
      display: 'flex',
      alignItems: 'flex-end',
      gap: 3
    }
  }, [40, 44, 42, 48, 46, 52, 50, 58, 63, 71, 78, 86, 92, 96].map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: h + '%',
      background: 'linear-gradient(180deg,#C4963Faa,#C4963F14)',
      borderTop: '1px solid var(--status-warning)'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, [['First seen', '12:01'], ['Occurrences', '7'], ['Trace id', '7f2a·9c04·be11'], ['Owner', 'Rin Aoki']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      padding: 'var(--space-3) 0',
      borderBottom: '1px solid var(--border-hairline)',
      fontSize: 'var(--text-body-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-faint)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-body)'
    }
  }, v)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    block: true,
    icon: "check"
  }, "Acknowledge"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "bell-off"
  }, "Mute"))));
}
Object.assign(window, {
  SignalDetail
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile/SignalDetail.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
