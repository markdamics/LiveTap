# Ginei Design System

Ginei is a house design language for building calm, precise product surfaces. It is not tied to a single
application: it exists so that several products — a marketing site, a web application, a mobile app — read as
one family. The visual brief is *futuristic elegance by way of Japanese zen*: deep night surfaces, moonlight
as the only interactive colour, a single monospaced voice, tight corners, hairline structure, and space (間, *ma*)
treated as a designed element rather than leftover room.

## Sources

This system was authored from a written brief supplied in conversation, with no external inputs:

- No codebase, repository, or local folder was attached.
- No Figma file or link was supplied.
- No slide decks, screenshots, or existing product screens were supplied.
- No logo or brand assets were supplied. **There is therefore no logo mark.** Wherever a mark would sit, the
  word *Ginei* is set in the display face (see `guidelines/wordmark.html`). Do not invent a symbol.

Direction confirmed by the user: brand name **Ginei**; a design system serving multiple products; surfaces =
marketing website, web app/dashboard, mobile app; palette = *Yoru* (deep charcoal-blue dark) with pale
moonlight accents; futurism = subtle glow; type = fully monospaced (JetBrains Mono across display, body and labels alike, confirmed in a later round);
UI copy in **English only** (no Japanese in interface text); density = balanced; motion = precise short slides
with subtle easing; **both dark and light themes are first-class**; demo content = neutral "Ginei" product
screens.

Because no source defined a component inventory, the component set is the standard primitive set, sized to the
brand (see *Components* below).

## Content fundamentals

Ginei copy sounds like a careful colleague, not a product. It states what is true, then stops.

- **Voice.** Plain declaratives. Short sentences that could be read aloud without emphasis. No exclamation
  marks anywhere in the interface.
- **Person.** Address the reader as *you*; the product refers to itself in the third person or not at all.
  Never *we* in product UI ("Your workspace is ready", not "We've set up your workspace"). *We* is allowed on
  the marketing site only, and sparingly.
- **Casing.** Sentence case for everything a human reads — headings, buttons, menu items, dialog titles
  (`Discard this draft?`, `Open workspace`). Uppercase is reserved for mono micro-labels, where it always
  carries `0.16em` tracking (`OVERVIEW`, `LATENCY`, `LAST 24H`).
- **Buttons.** A verb, one or two words: `Begin`, `Save snapshot`, `Discard`. Never `Click here`, never
  `Get started now`.
- **Marketing headlines.** Six words or fewer, no colon-subtitle construction, no "the future of".
  Shipped examples: *Stillness scales.* / *Everything, in one quiet place.* / *Precision without noise.*
- **Body copy.** One idea per paragraph, 62-character measure, no rhetorical questions. Example:
  "Ginei keeps every signal in one place and shows you only what changed. Nothing is hidden; nothing shouts."
- **Empty states.** Describe the state and the single next action. "No sources yet. Connect one to begin."
- **Errors.** Say what happened and what to do. "Ingest failed. Retrying in 30 seconds." Never blame the
  user, never apologise twice.
- **Numbers.** Always in mono, always with units, never rounded up for effect: `142 ms`, `99.98%`, `12 sources`.
- **Emoji.** Never. Not in UI, not in marketing, not in empty states.
- **Japanese text.** Not used in interface copy. Japanese words appear only as internal token names
  (*yoru*, *tsuki*, *shu*, *ma*, *washi*) documented here — never rendered to users.
- **Forbidden register.** No hype verbs (*supercharge*, *unlock*, *revolutionise*), no "AI-powered" as a
  boast, no ellipses for suspense, no sentence fragments used as taglines.

## Visual foundations

**Colour.** One palette, two themes, nine accents. *Yoru* (dark) is native: canvas `#04060A`, base `#070A0F`, cards
`#0B1017`, raised `#111823`. *Asa* (light) is a full peer, keyed on `[data-theme="light"]`, built on washi
whites (`#F5F7FA` / `#E9EDF3`) with white cards. Neutrals are the *mist* ramp — slightly blue-grey, never
warm. There is exactly one interactive colour: *tsuki* moonlight blue (`#8CBFE4` dark, `#3E7AA6` light). One
brand accent besides it, *shu* vermilion (`#CF5533`), used as a seal: destructive actions and, at most, one
mark per view. The accent itself is swappable: `tokens/accents.css` defines nine 5-step ramps — *tsuki*
(moonlight blue, default), *seiji* (celadon teal), *matcha* (muted green), *wakaba* (young-leaf lime), *fuji*
(wisteria violet), *sakura* (pale rose), *kohaku* (amber), *shu* (vermilion) and *nezu* (graphite, for products that want no chroma at all) — selected with `data-accent` on any element or on `<html>`.
Everything accent-derived (fills, hover hairlines, 12% washes, focus rings, glows, links, accent badges) is
computed from that ramp with `color-mix`, so one attribute retints the system and both themes stay in step:
`<html data-theme="light" data-accent="matcha">`. Both attributes must sit on the same element (theme on an
ancestor with the accent on a descendant falls back to the dark mapping). One accent per product surface —
never two in one view. Semantics are deliberately desaturated (`#6E9E7F` success, `#C4963F` warning) so nothing
competes with the accent. No colour is used decoratively; a coloured element is always interactive or a status.

**Type.** One family: JetBrains Mono, everywhere. Display (hero 64px, section 36px, title 28px) runs at
`-0.04em` tracking and weight 400 — never bolded past 500; body and control text at 17/15/13/11px on 1.55;
micro-labels uppercase at `0.16em`. With no pairing to lean on, hierarchy comes from scale, weight and
tracking alone, which is why the display sizes are set wide apart and the tracking is negative at the top of
the scale and positive at the bottom. `--font-display` and `--font-sans` remain as aliases of `--font-mono`,
so reintroducing a pairing later is a one-line change and no consuming code has to move. Prose measure is capped at 62 characters. Display text is never
uppercase; mono labels are never sentence case.

**Spacing.** 4px base with a widening scale (2, 4, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192). Card padding 24;
sibling stacks 16; section rhythm 96 vertical. Content width 1160px, narrow column 720px. Density is
*balanced*: controls are 30/38/46px tall, not compressed, but the page is not padded to emptiness either.
Emptiness is intentional and load-bearing — when a layout feels thin, reduce content, do not add ornament.

**Backgrounds.** Flat colour, essentially always. No photography is shipped with this system (none was
supplied). The only permitted background treatments are (a) a very low-contrast radial bloom of the accent
behind a hero, and (b) a 1px hairline grid or single rule used as structure. No gradients as decoration, no
noise textures, no illustrations, no full-bleed imagery. If a product needs photography, it should be cool-
toned, low-contrast, near-monochrome with a blue cast, never warm or saturated.

**Borders and structure.** Structure is drawn with 1px lines: `--border-hairline` (`#2E3B4C99` dark,
`#B4C0CD80` light) for almost everything, `--border-strong` for controls that must read as editable,
`--border-accent` for selected state. Dividers may fade to transparent at both ends. Thick borders (2px) exist
only as the left tone bar on a toast.

**Corners.** Tight: 2px (badge), 3px (button, input), 6px (segmented control, small panel), 10px (card),
16px (large panel, mobile sheet). Fully rounded (`999px`) is reserved for tags and switch tracks. Nothing else
is pill-shaped — no pill buttons.

**Shadow and glow.** Elevation is expressed as light before shadow. Every raised surface starts with a
hairline plus `inset 0 1px 0 #ffffff0a`. Drop shadows are long, soft and near-black
(`0 8px 24px -8px #04060a80`), never tight or grey. "Subtle glow" is specifically: `--glow-accent`
(`0 0 24px -6px` accent) behind primary buttons and one hero card, `--glow-edge` (inset 1px accent hairline)
on hover of interactive cards, and `--glow-focus` (1px accent ring + 4px halo) on focus. Glow is never applied
to text and never to more than one resting element per view.

**Focus, hover, press.** Hover *lightens by adding a line, not by tinting a fill*: outlines shift to
`--border-accent`, ghost controls take an `--accent-quiet` (12% accent) wash, text moves one step brighter.
Press is a 1px downward translate (`translateY(1px)`) with no colour change and no scale. Focus is always the
accent ring + halo, never a browser outline. Disabled is `opacity: .38` with shadows removed.

**Motion.** Precise and short. One curve for everything: `cubic-bezier(.22,.61,.36,1)`. Durations 80/140/200/
320ms. Entrances translate 6px (dialogs rise, toasts slide in from the right) and fade; exits are faster and
do not translate. Nothing bounces, nothing springs, nothing loops except a status pulse. All durations collapse
to 0 under `prefers-reduced-motion`.

**Transparency and blur.** Used in exactly two places: the modal scrim (`#04060Ac9` + 6px blur) and sticky
navigation bars (surface at ~80% + 20px blur). Never on cards, never behind body text.

**Cards.** Flat surface colour, 1px hairline, 10px radius, 24px padding, inset top highlight, no drop shadow at
rest. `raised` adds a soft shadow, `quiet` drops the border, `glow` adds the accent bloom (one per view).
Interactive cards gain an accent hairline and edge glow on hover — they never lift or scale.

**Layout rules.** Fixed elements are limited to one top bar (blurred, hairline bottom edge) and, on mobile, one
bottom tab bar (44px minimum targets). Sidebars are static, 240px, hairline-separated, no shadow. Content is
centred in a 1160px column with 24px gutters. Tables and lists are separated by hairlines only — no zebra
striping, no filled row hovers beyond the 4% wash.

## Iconography

- **Set:** [Lucide](https://lucide.dev) (`lucide-static@0.427.0`), loaded from unpkg. **This is a
  substitution** — no icon set was supplied with the brief. Lucide was chosen for its 1.5px stroke and open,
  geometric forms, which sit closest to the hairline language above. If Ginei acquires a real icon set, replace
  the CDN constant in `components/core/Icon.jsx` and the mask URL in `components/forms/Checkbox.jsx`.
- **Mechanism:** icons are rendered by the `Icon` component as a masked span (`mask-image` + `background:
  currentColor`), so every glyph inherits text colour and needs no per-colour variant. Do not paste inline SVG
  into product code, and never re-draw a glyph by hand.
- **Sizes:** 12px micro, 14px inside small controls, 16px default, 18–20px in navigation. Never above 24px —
  the stroke weight stops matching the hairlines.
- **Colour:** icons take `--text-muted` at rest and `--text-strong` on hover; status icons take the matching
  `--status-*` token. Icons are never the accent colour unless they *are* the interactive element.
- **Emoji:** never used, in any surface.
- **Unicode as iconography:** avoided, with one exception — the middle dot `·` as a metadata separator
  (`ginei-core · 12:04`). Arrows, checks and chevrons always come from Lucide, never from Unicode.
- **Brand mark:** none exists. The wordmark *Ginei* in JetBrains Mono at `0.06em` tracking stands in for a
  logo, in `--text-strong` only.

## Intentional additions

- **`Icon`** — a wrapper over the Lucide static set. Added because the brief supplied no icon system and every
  other component needs one; it centralises the substitution so it can be swapped in one place.
- **`Field`** — label/hint/error wrapper. Added so the uppercase mono label rule is enforced by the component
  rather than by convention.

## Index

Root:

- `styles.css` — the single entry point consumers link. `@import` lines only.
- `readme.md` — this document.
- `SKILL.md` — Agent-Skills front matter for use outside this project.
- `thumbnail.html` — homepage tile.

`tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css`,
`motion.css`, `base.css` (global floor: resets, heading defaults, link colours).

`components/` — each directory holds `<Name>.jsx`, `<Name>.d.ts`, `<Name>.prompt.md`, a shared stylesheet, and
one `@dsCard` preview:

- `core/` — Button, IconButton, Icon, Card, Badge, Tag
- `forms/` — Field, Input, Select, Checkbox, Radio, Switch
- `navigation/` — Tabs
- `feedback/` — Dialog, Toast, Tooltip

`guidelines/` — 18 foundation specimen cards: colour ramps (ink, mist, tsuki, shu, semantic, surfaces), type
(display, body, mono, scale), spacing (scale, in use), and brand (radii, elevation, motion, hairlines,
wordmark, iconography).

`ui_kits/` — full-screen recreations composed from the components above:

- `marketing/` — Ginei public site
- `app/` — Ginei web application (dashboard)
- `mobile/` — Ginei mobile app

`assets/` — empty. No logos, icons, illustrations or imagery were supplied; icons come from the Lucide CDN and
no photography ships with this system.

## Known substitutions to resolve

1. **Fonts.** JetBrains Mono is loaded from Google Fonts because no licensed binaries were supplied. Supply
   the real font files and `tokens/fonts.css` should be rewritten as local `@font-face` rules.
2. **Icons.** Lucide is a stand-in for a real Ginei icon set (see Iconography).
3. **Logo.** Absent by design — nothing was supplied and nothing was invented.
